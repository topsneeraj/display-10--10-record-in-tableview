//
//  main.m
//  loadingrecords
//
//  Created by Neeraj Agnihotri on 25/05/17.
//  Copyright © 2017 Neeraj Agnihotri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
