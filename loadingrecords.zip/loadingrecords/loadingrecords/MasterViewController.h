//
//  MasterViewController.h
//  DataLoader
//
//  Created by Upul Abayagunawardhana on 1/24/15.
//  Copyright (c) 2015 uiroshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

